﻿using CapaPresentacion.Custom;
using CapaEntidades;
using CapaLogicaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Text.RegularExpressions;

namespace PaginaWebClinina
{
    public partial class PanelGeneral : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
            }
        }

        [WebMethod]
        public static bool Logout()
        {
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            return true;
        }

        // API interna del asistente. Usa las capas existentes del proyecto
        // para consultar y registrar datos, sin crear rutas nuevas.
        [WebMethod(EnableSession = true)]
        public static string AsistenteIA(string mensaje)
        {
            if (string.IsNullOrWhiteSpace(mensaje))
                return "Escríbeme lo que necesitas y te ayudo.";

            mensaje = mensaje.Trim();

            if (EsCancelar(mensaje))
            {
                LimpiarAsistente();
                return "Listo. Cancelé la operación. ¿Qué necesitas hacer ahora?";
            }

            try
            {
                string flujo = Convert.ToString(HttpContext.Current.Session["Asistente_Flujo"]);

                if (string.Equals(flujo, "USUARIO", StringComparison.OrdinalIgnoreCase))
                    return ProcesarCrearUsuario(mensaje);

                if (string.Equals(flujo, "CITA", StringComparison.OrdinalIgnoreCase))
                    return ProcesarCrearCita(mensaje);

                string normalizado = Normalizar(mensaje);

                if (Contiene(normalizado, "crear usuario", "registrar usuario", "nuevo usuario", "crear una cuenta", "registrar una cuenta"))
                {
                    Usuario usuarioActual = HttpContext.Current.Session["UserSessionEmpleado"] as Usuario;
                    if (usuarioActual == null)
                        return "Debes iniciar sesión antes de crear un usuario.";

                    if (!string.Equals(usuarioActual.TipUser, "Administrador", StringComparison.OrdinalIgnoreCase))
                        return "Tu cuenta no tiene autorización para crear usuarios. El asistente respeta los permisos del sistema.";

                    HttpContext.Current.Session["Asistente_Flujo"] = "USUARIO";
                    HttpContext.Current.Session["Asistente_Paso"] = "DNI";
                    return "Claro. Voy a crear el usuario usando el registro de un empleado existente. Primero dime el número de documento del empleado.";
                }

                if (Contiene(normalizado, "crear cita", "agendar cita", "reservar cita", "programar cita", "sacar cita", "pedir cita"))
                {
                    if (HttpContext.Current.Session["UserSessionEmpleado"] == null)
                        return "Debes iniciar sesión antes de reservar una cita.";

                    HttpContext.Current.Session["Asistente_Flujo"] = "CITA";
                    HttpContext.Current.Session["Asistente_Paso"] = "DNI";
                    return "Perfecto. Vamos a reservar la cita. Primero dime el documento del paciente.";
                }

                // Preguntas generales: se intenta usar una IA online pública sin API key.
                return PreguntaIAOnline(mensaje);
            }
            catch (Exception ex)
            {
                // No exponemos detalles de la base de datos al navegador.
                return "No pude completar la operación. Verifica los datos e inténtalo nuevamente.";
            }
        }

        private static string ProcesarCrearUsuario(string mensaje)
        {
            string paso = Convert.ToString(HttpContext.Current.Session["Asistente_Paso"]);

            if (paso == "DNI")
            {
                string dni = ExtraerDocumento(mensaje);
                if (string.IsNullOrEmpty(dni))
                    return "Necesito el número de documento del empleado. Por ejemplo: 12345678.";

                Empleado empleado = EmpleadoLN.getInstance().BuscarEmpleado(dni);
                if (empleado == null || empleado.ID <= 0)
                    return "No encontré un empleado con ese documento. Verifica el número e inténtalo otra vez.";

                HttpContext.Current.Session["Asistente_EmpleadoId"] = empleado.ID.ToString();
                HttpContext.Current.Session["Asistente_EmpleadoNombre"] =
                    (empleado.Nombre + " " + empleado.ApPaterno + " " + empleado.ApMaterno).Trim();

                HttpContext.Current.Session["Asistente_Paso"] = "USUARIO";
                return "Encontré a " + (empleado.Nombre + " " + empleado.ApPaterno).Trim() +
                       ". Ahora dime el nombre de usuario que quieres crear.";
            }

            if (paso == "USUARIO")
            {
                if (mensaje.Length < 3)
                    return "El nombre de usuario es demasiado corto. Dime otro.";

                HttpContext.Current.Session["Asistente_NombreUsuario"] = mensaje.Trim();
                HttpContext.Current.Session["Asistente_Paso"] = "CLAVE";
                return "Perfecto. Ahora dime la contraseña que tendrá la cuenta.";
            }

            if (paso == "CLAVE")
            {
                if (mensaje.Length < 4)
                    return "La contraseña debe tener al menos 4 caracteres. Inténtalo nuevamente.";

                HttpContext.Current.Session["Asistente_Clave"] = mensaje;
                HttpContext.Current.Session["Asistente_Paso"] = "ROL";
                return "¿Qué rol tendrá? Escribe «Administrador» o «Invitado».";
            }

            if (paso == "ROL")
            {
                string rol = Normalizar(mensaje);
                string tipo = rol.Contains("administrador") ? "Administrador" :
                              (rol.Contains("invitado") ? "Invitado" : "");

                if (string.IsNullOrEmpty(tipo))
                    return "El rol debe ser «Administrador» o «Invitado».";

                int idEmpleado = Convert.ToInt32(HttpContext.Current.Session["Asistente_EmpleadoId"]);
                string nombreUsuario = Convert.ToString(HttpContext.Current.Session["Asistente_NombreUsuario"]);
                string clave = Convert.ToString(HttpContext.Current.Session["Asistente_Clave"]);

                Usuario nuevo = new Usuario();
                nuevo.IdUsuario = 0;
                nuevo.user = nombreUsuario;
                nuevo.password = clave;
                nuevo.ID = idEmpleado;
                nuevo.TipUser = tipo;
                nuevo.estado = true;

                bool ok = UsuarioLN.getInstance().RegistrarUsuario(nuevo);
                string empleadoNombre = Convert.ToString(HttpContext.Current.Session["Asistente_EmpleadoNombre"]);
                LimpiarAsistente();

                return ok
                    ? "Usuario creado correctamente para " + empleadoNombre + ". Usuario: " + nombreUsuario + "."
                    : "No se pudo crear el usuario. Puede que el usuario ya exista o que la base de datos haya rechazado el registro.";
            }

            LimpiarAsistente();
            return "La operación de usuario se reinició. Si quieres, dime «crear usuario» para comenzar.";
        }

        private static string ProcesarCrearCita(string mensaje)
        {
            string paso = Convert.ToString(HttpContext.Current.Session["Asistente_Paso"]);

            if (paso == "DNI")
            {
                string dni = ExtraerDocumento(mensaje);
                if (string.IsNullOrEmpty(dni))
                    return "Necesito el documento del paciente. Por ejemplo: 12345678.";

                Paciente paciente = PacienteLN.getInstance().BuscarPacienteDNI(dni);
                if (paciente == null || paciente.IdPaciente <= 0)
                    return "No encontré un paciente con ese documento. Primero registra al paciente en el sistema.";

                HttpContext.Current.Session["Asistente_PacienteId"] = paciente.IdPaciente.ToString();
                HttpContext.Current.Session["Asistente_PacienteNombre"] =
                    (paciente.Nombres + " " + paciente.ApPaterno).Trim();

                HttpContext.Current.Session["Asistente_Paso"] = "ESPECIALIDAD";
                return "Paciente encontrado: " + (paciente.Nombres + " " + paciente.ApPaterno).Trim() +
                       ". ¿Qué especialidad necesitas?";
            }

            if (paso == "ESPECIALIDAD")
            {
                List<Especialidad> especialidades = EspecialidadLN.getInstance().Listar();
                Especialidad seleccionada = especialidades
                    .FirstOrDefault(x => Normalizar(x.Descripcion) == Normalizar(mensaje))
                    ?? especialidades.FirstOrDefault(x => Normalizar(x.Descripcion).Contains(Normalizar(mensaje)));

                if (seleccionada == null)
                {
                    string disponibles = string.Join(", ", especialidades.Select(x => x.Descripcion));
                    return "No encontré esa especialidad. Las disponibles son: " + disponibles;
                }

                HttpContext.Current.Session["Asistente_EspecialidadId"] = seleccionada.IdEspecialidad.ToString();
                HttpContext.Current.Session["Asistente_EspecialidadNombre"] = seleccionada.Descripcion;
                HttpContext.Current.Session["Asistente_Paso"] = "FECHA";
                return "Perfecto, especialidad: " + seleccionada.Descripcion +
                       ". ¿Para qué fecha quieres la cita? Puedes escribir «mañana», «hoy» o una fecha como 25/08/2026.";
            }

            if (paso == "FECHA")
            {
                DateTime fecha;
                if (!TryParseFecha(mensaje, out fecha))
                    return "No entendí la fecha. Escríbela como 25/08/2026, o dime «hoy» o «mañana».";

                if (fecha.Date < DateTime.Now.Date)
                    return "La fecha debe ser hoy o una fecha futura.";

                int idEspecialidad = Convert.ToInt32(HttpContext.Current.Session["Asistente_EspecialidadId"]);
                List<HorarioAtencion> horarios = HorarioAtencionLN.getInstance().ListarHorarioReservas(idEspecialidad, fecha.Date);

                if (horarios == null || horarios.Count == 0)
                    return "No hay horarios disponibles para esa especialidad el " +
                           fecha.ToString("dd/MM/yyyy") + ". Prueba con otra fecha.";

                HttpContext.Current.Session["Asistente_Fecha"] = fecha.ToString("yyyy-MM-dd");
                HttpContext.Current.Session["Asistente_Horarios"] = SerializarHorarios(horarios);
                HttpContext.Current.Session["Asistente_Paso"] = "HORA";

                string opciones = string.Join(" | ", horarios.Select((h, i) =>
                    (i + 1) + ". " + h.Hora.hora + " - Dr(a). " + h.Medico.Nombre));

                return "Hay estos horarios disponibles para " + fecha.ToString("dd/MM/yyyy") +
                       ": " + opciones + ". Dime la hora que prefieres.";
            }

            if (paso == "HORA")
            {
                List<HorarioOpcion> horarios = DeserializarHorarios(
                    Convert.ToString(HttpContext.Current.Session["Asistente_Horarios"]));

                string hora = ExtraerHora(mensaje);
                HorarioOpcion seleccion = null;

                if (!string.IsNullOrEmpty(hora))
                    seleccion = horarios.FirstOrDefault(x => NormalizarHora(x.Hora) == NormalizarHora(hora));

                if (seleccion == null)
                {
                    int numero;
                    if (int.TryParse(mensaje.Trim(), out numero) && numero >= 1 && numero <= horarios.Count)
                        seleccion = horarios[numero - 1];
                }

                if (seleccion == null)
                {
                    string opciones = string.Join(" | ", horarios.Select((h, i) => (i + 1) + ". " + h.Hora));
                    return "No encontré ese horario. Elige uno de estos: " + opciones;
                }

                DateTime fecha = DateTime.Parse(Convert.ToString(HttpContext.Current.Session["Asistente_Fecha"]));
                int idPaciente = Convert.ToInt32(HttpContext.Current.Session["Asistente_PacienteId"]);

                Cita cita = new Cita();
                cita.Paciente.IdPaciente = idPaciente;
                cita.Medico.IdMedico = seleccion.IdMedico;
                cita.FechaReserva = fecha;
                cita.Hora = seleccion.Hora;

                bool ok = CitaLN.getInstance().RegistrarCita(cita);
                string pacienteNombre = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteNombre"]);
                string especialidad = Convert.ToString(HttpContext.Current.Session["Asistente_EspecialidadNombre"]);

                LimpiarAsistente();

                return ok
                    ? "¡Cita registrada correctamente! Paciente: " + pacienteNombre +
                      ". Especialidad: " + especialidad +
                      ". Fecha: " + fecha.ToString("dd/MM/yyyy") +
                      ". Hora: " + seleccion.Hora + "."
                    : "No se pudo registrar la cita. El horario puede haber sido ocupado. Intenta reservar nuevamente.";
            }

            LimpiarAsistente();
            return "La operación de cita se reinició. Si quieres, dime «crear cita» para comenzar.";
        }

        private static string PreguntaIAOnline(string mensaje)
        {
            try
            {
                string prompt = ConstruirPromptConversacion(mensaje);

                // Servicio online sin API key. Se usan endpoints documentados públicamente.
                // El primero es el recomendado; los siguientes funcionan como respaldo.
                // Servicios públicos sin API key. Se prueban varios endpoints
                // y se descartan respuestas de error o respuestas que solo contienen
                // el nombre del proveedor.
                // Servicios públicos de IA sin API key. Se usan los parámetros
                // que figuran en la documentación actual de los endpoints.
                string encodedPrompt = Uri.EscapeDataString(prompt);
                string[] urls =
                {
                    "https://prexzyapis.com/ai/chatgpt?prompt=" + encodedPrompt,
                    "https://prexzyapis.com/ai/gpt-5?text=" + encodedPrompt,
                    "https://prexzyapis.com/ai/gemini25?prompt=" + encodedPrompt,
                    "https://prexzyapis.com/ai/gemma27free?prompt=" + encodedPrompt,
                    "https://prexzyapis.com/ai/ai4chat?prompt=" + encodedPrompt,
                    "https://prexzyapis.com/ai/ch?q=" + encodedPrompt
                };

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                foreach (string url in urls)
                {
                    try
                    {
                        using (WebClient cliente = new WebClient())
                        {
                            cliente.Encoding = Encoding.UTF8;
                            cliente.Headers[HttpRequestHeader.UserAgent] = "ClinicaAsistente/1.0";
                            cliente.Headers[HttpRequestHeader.Accept] = "application/json,text/plain,*/*";

                            string respuesta = cliente.DownloadString(url);
                            string texto = ExtraerRespuestaIA(respuesta);

                            if (EsRespuestaIAValida(texto))
                            {
                                texto = LimpiarTextoIA(texto);
                                if (EsRespuestaIAValida(texto))
                                {
                                    GuardarConversacion(mensaje, texto);
                                    return texto;
                                }
                            }
                        }
                    }
                    catch
                    {
                        // Intenta el siguiente servicio de respaldo.
                    }
                }
            }
            catch
            {
                // Las operaciones internas de usuarios y citas no dependen de la IA online.
            }

            return "En este momento no pude conectarme con el servicio de IA en línea. " +
                   "Puedes volver a intentarlo en unos segundos o usar «crear usuario» y «crear cita» para las funciones del sistema.";
        }

        private static bool EsRespuestaIAValida(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            string t = texto.Trim();

            // No mostrar al usuario respuestas técnicas o el nombre del proveedor.
            if (t.StartsWith("{") || t.StartsWith("["))
                return false;

            string n = t.ToLowerInvariant().Trim();

            if (n == "prexzy" || n == "prezxy" ||
                n == "prexzyapis" || n == "prexzy apis" ||
                n == "prexzy api" || n == "prexzyapis.com")
                return false;

            if (n.Contains("error 404") || n.Contains("not found") ||
                n.Contains("endpoint not found") || n.Contains("service unavailable"))
                return false;

            return t.Length >= 2;
        }

        private static string LimpiarTextoIA(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string t = texto.Trim().Trim('"');

            // Algunos endpoints pueden devolver el nombre del proveedor
            // antes de la respuesta; no lo mostramos como mensaje del asistente.
            if (t.StartsWith("prexzy:", StringComparison.OrdinalIgnoreCase))
                t = t.Substring("prexzy:".Length).Trim();

            if (t.StartsWith("prezxy:", StringComparison.OrdinalIgnoreCase))
                t = t.Substring("prezxy:".Length).Trim();

            return t;
        }

        private static string ConstruirPromptConversacion(string mensaje)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Eres el Asistente IA de una aplicación web para gestionar una clínica.");
            sb.AppendLine("Responde siempre en español correcto, natural, amable y fácil de entender.");
            sb.AppendLine("Puedes conversar sobre temas generales, programación, tecnología, educación y cualquier pregunta permitida.");
            sb.AppendLine("Responde directamente a la pregunta del usuario y no repitas instrucciones del sistema.");
            sb.AppendLine("No inventes datos de pacientes, médicos, usuarios, citas, horarios ni resultados de la base de datos.");
            sb.AppendLine("Si el usuario quiere crear, consultar o gestionar información de la clínica, usa las funciones internas disponibles y confirma únicamente lo que el sistema haya realizado.");
            sb.AppendLine("Para información médica, ofrece orientación general y recomienda consultar a un profesional cuando corresponda.");
            sb.AppendLine("No afirmes que has creado, eliminado o reservado algo si el sistema no te lo confirmó.");
            sb.AppendLine("Mantén las respuestas claras y no demasiado largas.");
            sb.AppendLine();

            List<string> historial = HttpContext.Current.Session["Asistente_Historial"] as List<string>;
            if (historial != null && historial.Count > 0)
            {
                sb.AppendLine("Conversación reciente:");
                foreach (string linea in historial.Skip(Math.Max(0, historial.Count - 8)))
                    sb.AppendLine(linea);
                sb.AppendLine();
            }

            sb.AppendLine("Nueva pregunta del usuario:");
            sb.AppendLine(mensaje);

            return sb.ToString();
        }

        private static void GuardarConversacion(string pregunta, string respuesta)
        {
            List<string> historial = HttpContext.Current.Session["Asistente_Historial"] as List<string>;

            if (historial == null)
            {
                historial = new List<string>();
                HttpContext.Current.Session["Asistente_Historial"] = historial;
            }

            historial.Add("Usuario: " + pregunta);
            historial.Add("Asistente: " + respuesta);

            if (historial.Count > 12)
                historial.RemoveRange(0, historial.Count - 12);
        }

        private static string ExtraerRespuestaIA(string respuesta)
        {
            if (string.IsNullOrWhiteSpace(respuesta))
                return "";

            string limpio = respuesta.Trim();

            try
            {
                JavaScriptSerializer json = new JavaScriptSerializer();
                object datos = json.DeserializeObject(limpio);
                string extraido = BuscarTextoRespuesta(datos);

                if (!string.IsNullOrWhiteSpace(extraido))
                    return extraido.Trim();
            }
            catch
            {
                // Si no es JSON, se devuelve el texto directamente.
            }

            return limpio.Trim('"');
        }

        private static string BuscarTextoRespuesta(object datos)
        {
            if (datos == null)
                return "";

            string texto = datos as string;
            if (!string.IsNullOrWhiteSpace(texto))
                return texto;

            Dictionary<string, object> dic = datos as Dictionary<string, object>;
            if (dic != null)
            {
                string[] claves = { "result", "response", "answer", "text", "message", "content" };

                foreach (string clave in claves)
                {
                    object valor;
                    if (dic.TryGetValue(clave, out valor))
                    {
                        string encontrado = BuscarTextoRespuesta(valor);
                        if (!string.IsNullOrWhiteSpace(encontrado))
                            return encontrado;
                    }
                }

                foreach (object valor in dic.Values)
                {
                    string encontrado = BuscarTextoRespuesta(valor);
                    if (!string.IsNullOrWhiteSpace(encontrado))
                        return encontrado;
                }
            }

            object[] arreglo = datos as object[];
            if (arreglo != null)
            {
                foreach (object valor in arreglo)
                {
                    string encontrado = BuscarTextoRespuesta(valor);
                    if (!string.IsNullOrWhiteSpace(encontrado))
                        return encontrado;
                }
            }

            return "";
        }

        private static bool EsCancelar(string texto)
        {
            string n = Normalizar(texto);
            return n == "cancelar" || n == "cancelar operacion" || n == "salir" ||
                   n == "reiniciar" || n == "empezar de nuevo";
        }

        private static bool Contiene(string texto, params string[] opciones)
        {
            return opciones.Any(x => texto.Contains(Normalizar(x)));
        }

        private static string Normalizar(string texto)
        {
            if (string.IsNullOrEmpty(texto)) return "";
            string n = texto.ToLowerInvariant().Trim();
            n = n.Replace("á", "a").Replace("é", "e").Replace("í", "i")
                 .Replace("ó", "o").Replace("ú", "u").Replace("ü", "u").Replace("ñ", "n");
            return Regex.Replace(n, @"\s+", " ");
        }

        private static string ExtraerDocumento(string texto)
        {
            Match m = Regex.Match(texto ?? "", @"\b\d{6,12}\b");
            return m.Success ? m.Value : "";
        }

        private static bool TryParseFecha(string texto, out DateTime fecha)
        {
            string n = Normalizar(texto);
            if (n.Contains("manana"))
            {
                fecha = DateTime.Now.Date.AddDays(1);
                return true;
            }

            if (n == "hoy" || n.Contains("hoy"))
            {
                fecha = DateTime.Now.Date;
                return true;
            }

            string[] formatos = { "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd", "dd-MM-yyyy", "d-M-yyyy" };
            return DateTime.TryParseExact(texto.Trim(), formatos,
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out fecha)
                || DateTime.TryParse(texto.Trim(),
                    new System.Globalization.CultureInfo("es-CO"),
                    System.Globalization.DateTimeStyles.None, out fecha);
        }

        private static string ExtraerHora(string texto)
        {
            Match m = Regex.Match((texto ?? "").ToLowerInvariant(),
                @"\b([01]?\d|2[0-3])(?::([0-5]\d))?\s*(am|pm)?\b");

            if (!m.Success) return "";

            int h = Convert.ToInt32(m.Groups[1].Value);
            int min = m.Groups[2].Success ? Convert.ToInt32(m.Groups[2].Value) : 0;
            string ampm = m.Groups[3].Value;

            if (ampm == "pm" && h < 12) h += 12;
            if (ampm == "am" && h == 12) h = 0;

            return h.ToString("00") + ":" + min.ToString("00");
        }

        private static string NormalizarHora(string hora)
        {
            if (string.IsNullOrEmpty(hora)) return "";
            return hora.Trim().Replace(".", ":").ToLowerInvariant();
        }

        private static string SerializarHorarios(List<HorarioAtencion> horarios)
        {
            List<HorarioOpcion> lista = horarios.Select(x => new HorarioOpcion
            {
                IdHorario = x.IdHorarioAtencion,
                IdMedico = x.Medico.IdMedico,
                Hora = x.Hora.hora,
                Medico = x.Medico.Nombre
            }).ToList();

            return new JavaScriptSerializer().Serialize(lista);
        }

        private static List<HorarioOpcion> DeserializarHorarios(string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return new List<HorarioOpcion>();

            return new JavaScriptSerializer().Deserialize<List<HorarioOpcion>>(texto)
                   ?? new List<HorarioOpcion>();
        }

        private static void LimpiarAsistente()
        {
            string[] claves =
            {
                "Asistente_Flujo", "Asistente_Paso", "Asistente_EmpleadoId",
                "Asistente_EmpleadoNombre", "Asistente_NombreUsuario",
                "Asistente_Clave", "Asistente_PacienteId", "Asistente_PacienteNombre",
                "Asistente_EspecialidadId", "Asistente_EspecialidadNombre",
                "Asistente_Fecha", "Asistente_Horarios", "Asistente_Historial"
            };

            foreach (string clave in claves)
                HttpContext.Current.Session.Remove(clave);
        }

        private class HorarioOpcion
        {
            public int IdHorario { get; set; }
            public int IdMedico { get; set; }
            public string Hora { get; set; }
            public string Medico { get; set; }
        }
    }
}
