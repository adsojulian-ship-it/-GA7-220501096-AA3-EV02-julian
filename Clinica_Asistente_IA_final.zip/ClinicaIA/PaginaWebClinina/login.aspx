<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="login.aspx.cs" Inherits="PaginaWebClinina.login" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="es">
<head runat="server">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="API CJS SENA - Servicio de Citas Médicas"/>
    <title>API CJS SENA | Iniciar Sesión</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <!-- CJS SENA: estilos visuales modernos -->
    <link href="css/cjs-modern.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="img/clinica_318-1538.jpg" />
</head>

<body class="cjs-login">
    <form id="form1" runat="server">
        <!-- LOGIN: se conservan los mismos controles ASP.NET -->
        <div class="form-box" id="login-box">
            <asp:Login ID="LoginUser" runat="server" EnableViewState="false"
                OnAuthenticate="LoginUser_Authenticate" Width="100%">
                <LayoutTemplate>
                    <div class="header">
                        <i class="fa fa-heartbeat" style="margin-right:8px;"></i>
                        Bienvenido
                    </div>

                    <div class="body">
                        <div style="text-align:center;margin:-4px 0 22px;color:#718096;font-size:13px;">
                            <strong style="color:#243447;">API CJS SENA</strong><br />
                            Servicio de Citas Médicas
                        </div>

                        <div class="form-group">
                            <label style="font-size:12px;color:#526273;font-weight:600;">Usuario</label>
                            <asp:TextBox ID="UserName" runat="server" CssClass="form-control"
                                placeholder="Ingrese su usuario"></asp:TextBox>
                        </div>

                        <div class="form-group">
                            <label style="font-size:12px;color:#526273;font-weight:600;">Contraseña</label>
                            <asp:TextBox ID="Password" runat="server" CssClass="form-control"
                                placeholder="Ingrese su contraseña" TextMode="Password"></asp:TextBox>
                        </div>
                    </div>

                    <div class="footer">
                        <asp:Button ID="btnIngresar" CommandName="Login" runat="server"
                            Text="Iniciar Sesión" CssClass="btn bg-blue btn-block" />
                    </div>
                </LayoutTemplate>
            </asp:Login>
        </div>
    </form>

    <script src="js/jquery-3.1.0.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html>
